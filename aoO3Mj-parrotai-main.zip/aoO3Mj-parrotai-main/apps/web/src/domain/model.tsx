import { AuthorizationRole as AuthorizationRoleModel } from './authorization/authorization.model'

import { User as UserModel } from './user/user.model'

import { Notification as NotificationModel } from './notification/notification.model'

import { VoiceModel as VoiceModelModel } from './voiceModel/voiceModel.model'

import { AudioFile as AudioFileModel } from './audioFile/audioFile.model'

import { ClonedVoice as ClonedVoiceModel } from './clonedVoice/clonedVoice.model'

export namespace Model {
  export class AuthorizationRole extends AuthorizationRoleModel {}

  export class User extends UserModel {}

  export class Notification extends NotificationModel {}

  export class VoiceModel extends VoiceModelModel {}

  export class AudioFile extends AudioFileModel {}

  export class ClonedVoice extends ClonedVoiceModel {}
}
