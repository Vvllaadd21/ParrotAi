import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { ClonedVoice } from './clonedVoice.model'

export class ClonedVoiceApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<ClonedVoice>,
  ): Promise<ClonedVoice[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/clonedVoices${buildOptions}`)
  }

  static findOne(
    clonedVoiceId: string,
    queryOptions?: ApiHelper.QueryOptions<ClonedVoice>,
  ): Promise<ClonedVoice> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/clonedVoices/${clonedVoiceId}${buildOptions}`,
    )
  }

  static createOne(values: Partial<ClonedVoice>): Promise<ClonedVoice> {
    return HttpService.api.post(`/v1/clonedVoices`, values)
  }

  static updateOne(
    clonedVoiceId: string,
    values: Partial<ClonedVoice>,
  ): Promise<ClonedVoice> {
    return HttpService.api.patch(`/v1/clonedVoices/${clonedVoiceId}`, values)
  }

  static deleteOne(clonedVoiceId: string): Promise<void> {
    return HttpService.api.delete(`/v1/clonedVoices/${clonedVoiceId}`)
  }

  static findManyByUserId(
    userId: string,
    queryOptions?: ApiHelper.QueryOptions<ClonedVoice>,
  ): Promise<ClonedVoice[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/users/user/${userId}/clonedVoices${buildOptions}`,
    )
  }

  static createOneByUserId(
    userId: string,
    values: Partial<ClonedVoice>,
  ): Promise<ClonedVoice> {
    return HttpService.api.post(`/v1/users/user/${userId}/clonedVoices`, values)
  }

  static findManyByAudioFileId(
    audioFileId: string,
    queryOptions?: ApiHelper.QueryOptions<ClonedVoice>,
  ): Promise<ClonedVoice[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/audioFiles/audioFile/${audioFileId}/clonedVoices${buildOptions}`,
    )
  }

  static createOneByAudioFileId(
    audioFileId: string,
    values: Partial<ClonedVoice>,
  ): Promise<ClonedVoice> {
    return HttpService.api.post(
      `/v1/audioFiles/audioFile/${audioFileId}/clonedVoices`,
      values,
    )
  }

  static findManyByVoiceModelId(
    voiceModelId: string,
    queryOptions?: ApiHelper.QueryOptions<ClonedVoice>,
  ): Promise<ClonedVoice[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/voiceModels/voiceModel/${voiceModelId}/clonedVoices${buildOptions}`,
    )
  }

  static createOneByVoiceModelId(
    voiceModelId: string,
    values: Partial<ClonedVoice>,
  ): Promise<ClonedVoice> {
    return HttpService.api.post(
      `/v1/voiceModels/voiceModel/${voiceModelId}/clonedVoices`,
      values,
    )
  }
}
