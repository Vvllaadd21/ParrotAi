import { User } from '../user'

import { AudioFile } from '../audioFile'

import { VoiceModel } from '../voiceModel'

export class ClonedVoice {
  id: string

  clonedFilename: string

  clonedFilepathUrl: string

  userId: string

  user?: User

  audioFileId: string

  audioFile?: AudioFile

  voiceModelId: string

  voiceModel?: VoiceModel

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
