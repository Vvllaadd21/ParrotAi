import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { VoiceModel } from './voiceModel.model'

export class VoiceModelApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<VoiceModel>,
  ): Promise<VoiceModel[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/voiceModels${buildOptions}`)
  }

  static findOne(
    voiceModelId: string,
    queryOptions?: ApiHelper.QueryOptions<VoiceModel>,
  ): Promise<VoiceModel> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/voiceModels/${voiceModelId}${buildOptions}`)
  }

  static createOne(values: Partial<VoiceModel>): Promise<VoiceModel> {
    return HttpService.api.post(`/v1/voiceModels`, values)
  }

  static updateOne(
    voiceModelId: string,
    values: Partial<VoiceModel>,
  ): Promise<VoiceModel> {
    return HttpService.api.patch(`/v1/voiceModels/${voiceModelId}`, values)
  }

  static deleteOne(voiceModelId: string): Promise<void> {
    return HttpService.api.delete(`/v1/voiceModels/${voiceModelId}`)
  }
}
