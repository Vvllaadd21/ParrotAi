import { AudioFile } from '../audioFile'

import { ClonedVoice } from '../clonedVoice'

export class VoiceModel {
  id: string

  name: string

  description?: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  audioFilesAsModel?: AudioFile[]

  clonedVoices?: ClonedVoice[]
}
