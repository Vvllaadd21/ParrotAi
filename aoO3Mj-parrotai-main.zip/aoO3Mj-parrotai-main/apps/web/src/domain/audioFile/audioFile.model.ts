import { User } from '../user'

import { VoiceModel } from '../voiceModel'

import { ClonedVoice } from '../clonedVoice'

export class AudioFile {
  id: string

  filename: string

  filepathUrl: string

  userId: string

  user?: User

  modelId: string

  model?: VoiceModel

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  clonedVoices?: ClonedVoice[]
}
