import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { AudioFile } from './audioFile.model'

export class AudioFileApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<AudioFile>,
  ): Promise<AudioFile[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/audioFiles${buildOptions}`)
  }

  static findOne(
    audioFileId: string,
    queryOptions?: ApiHelper.QueryOptions<AudioFile>,
  ): Promise<AudioFile> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/audioFiles/${audioFileId}${buildOptions}`)
  }

  static createOne(values: Partial<AudioFile>): Promise<AudioFile> {
    return HttpService.api.post(`/v1/audioFiles`, values)
  }

  static updateOne(
    audioFileId: string,
    values: Partial<AudioFile>,
  ): Promise<AudioFile> {
    return HttpService.api.patch(`/v1/audioFiles/${audioFileId}`, values)
  }

  static deleteOne(audioFileId: string): Promise<void> {
    return HttpService.api.delete(`/v1/audioFiles/${audioFileId}`)
  }

  static findManyByUserId(
    userId: string,
    queryOptions?: ApiHelper.QueryOptions<AudioFile>,
  ): Promise<AudioFile[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/users/user/${userId}/audioFiles${buildOptions}`,
    )
  }

  static createOneByUserId(
    userId: string,
    values: Partial<AudioFile>,
  ): Promise<AudioFile> {
    return HttpService.api.post(`/v1/users/user/${userId}/audioFiles`, values)
  }

  static findManyByModelId(
    modelId: string,
    queryOptions?: ApiHelper.QueryOptions<AudioFile>,
  ): Promise<AudioFile[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/voiceModels/model/${modelId}/audioFiles${buildOptions}`,
    )
  }

  static createOneByModelId(
    modelId: string,
    values: Partial<AudioFile>,
  ): Promise<AudioFile> {
    return HttpService.api.post(
      `/v1/voiceModels/model/${modelId}/audioFiles`,
      values,
    )
  }
}
