'use client'

import { useEffect, useState } from 'react'
import { Button, Form, Input, Typography, Upload, message, Modal } from 'antd'
import { UploadOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function EditAudioFilePage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [audioFile, setAudioFile] = useState(null)
  const [form] = Form.useForm()

  useEffect(() => {
    const fetchAudioFile = async () => {
      try {
        const audioFileFound = await Api.AudioFile.findOne(params.id, {
          includes: ['user', 'model'],
        })
        setAudioFile(audioFileFound)
        form.setFieldsValue({
          filename: audioFileFound.filename,
          filepathUrl: audioFileFound.filepathUrl,
        })
      } catch (error) {
        enqueueSnackbar('Failed to fetch audio file details', {
          variant: 'error',
        })
      }
    }

    if (params.id) fetchAudioFile()
  }, [params.id, form])

  const handleUpdate = async values => {
    try {
      await Api.AudioFile.updateOne(params.id, { ...values, userId: userId })
      enqueueSnackbar('Audio file updated successfully', { variant: 'success' })
      router.push('/cloning-history')
    } catch (error) {
      enqueueSnackbar('Failed to update audio file', { variant: 'error' })
    }
  }

  const handleUpload = async options => {
    const { file } = options
    try {
      const url = await Api.Upload.upload(file)
      form.setFieldsValue({ filepathUrl: url })
      message.success(`${file.name} file uploaded successfully`)
    } catch (error) {
      message.error(`${file.name} file upload failed.`)
    }
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Edit Audio File Metadata</Title>
      <Text>Edit the details of your uploaded audio file.</Text>
      {audioFile && (
        <Form
          form={form}
          layout="vertical"
          onFinish={handleUpdate}
          initialValues={{ filename: '', filepathUrl: '' }}
        >
          <Form.Item
            name="filename"
            label="File Name"
            rules={[{ required: true, message: 'Please input the file name!' }]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            name="filepathUrl"
            label="File Path URL"
            rules={[
              { required: true, message: 'Please input the file path URL!' },
            ]}
          >
            <Input readOnly />
          </Form.Item>
          <Form.Item>
            <Upload
              customRequest={handleUpload}
              maxCount={1}
              showUploadList={false}
            >
              <Button icon={<UploadOutlined />}>Click to Upload</Button>
            </Upload>
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit">
              Update
            </Button>
          </Form.Item>
        </Form>
      )}
    </PageLayout>
  )
}
