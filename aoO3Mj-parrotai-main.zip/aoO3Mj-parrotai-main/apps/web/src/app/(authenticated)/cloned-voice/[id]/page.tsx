'use client'

import React, { useEffect, useState } from 'react'
import { Button, Card, Col, Row, Typography, Space } from 'antd'
import { PlayCircleOutlined, DownloadOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function ClonedVoiceDetailsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { enqueueSnackbar } = useSnackbar()
  const [clonedVoiceDetails, setClonedVoiceDetails] = useState<any>(null)

  useEffect(() => {
    const fetchClonedVoiceDetails = async () => {
      try {
        const details = await Api.ClonedVoice.findOne(params.id, {
          includes: ['audioFile', 'voiceModel', 'audioFile.user'],
        })
        setClonedVoiceDetails(details)
      } catch (error) {
        enqueueSnackbar('Failed to fetch cloned voice details', {
          variant: 'error',
        })
      }
    }

    if (params.id) {
      fetchClonedVoiceDetails()
    }
  }, [params.id])

  const handlePlayAudio = (audioUrl: string) => {
    const audio = new Audio(audioUrl)
    audio.play().catch(error => {
      enqueueSnackbar('Failed to play the audio', { variant: 'error' })
    })
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Cloned Voice Details</Title>
      <Text type="secondary">
        Here you can find the details of your cloned voice.
      </Text>
      <Row gutter={[16, 16]} justify="center" style={{ marginTop: '20px' }}>
        <Col span={24}>
          <Card>
            <Space direction="vertical" size="middle">
              <Text>
                <strong>Original Filename:</strong>{' '}
                {clonedVoiceDetails?.audioFile?.filename}
              </Text>
              <Text>
                <strong>Cloned Filename:</strong>{' '}
                {clonedVoiceDetails?.clonedFilename}
              </Text>
              <Text>
                <strong>Original Uploader:</strong>{' '}
                {clonedVoiceDetails?.audioFile?.user?.name}
              </Text>
              <Text>
                <strong>Model Used:</strong>{' '}
                {clonedVoiceDetails?.voiceModel?.name}
              </Text>
              <Text>
                <strong>Date Created:</strong>{' '}
                {dayjs(clonedVoiceDetails?.dateCreated).format('DD/MM/YYYY')}
              </Text>
              <Space>
                <Button
                  type="primary"
                  icon={<PlayCircleOutlined />}
                  onClick={() =>
                    handlePlayAudio(clonedVoiceDetails?.clonedFilepathUrl)
                  }
                >
                  Play
                </Button>
                <Button
                  icon={<DownloadOutlined />}
                  onClick={() =>
                    window.open(clonedVoiceDetails?.clonedFilepathUrl, '_blank')
                  }
                >
                  Download
                </Button>
              </Space>
            </Space>
          </Card>
        </Col>
      </Row>
    </PageLayout>
  )
}
