'use client'

import React, { useState } from 'react'
import { Upload, Button, Typography, message, Modal } from 'antd'
import { InboxOutlined } from '@ant-design/icons'
const { Title, Paragraph } = Typography
const { Dragger } = Upload
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function UploadAudioPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [fileList, setFileList] = useState([])
  const [uploading, setUploading] = useState(false)

  const handleUpload = async options => {
    const { file, onSuccess, onError } = options
    setUploading(true)
    try {
      const filepathUrl = await Api.Upload.upload(file)
      const audioFile = await Api.AudioFile.createOneByUserId(userId, {
        filename: file.name,
        filepathUrl,
        modelId: '', // This should be set based on user selection or another logic
      })
      if (audioFile) {
        onSuccess('Ok')
        setFileList(fileList => [
          ...fileList,
          {
            uid: audioFile.id,
            name: audioFile.filename,
            status: 'done',
            url: audioFile.filepathUrl,
          },
        ])
        enqueueSnackbar('File uploaded successfully', { variant: 'success' })
      } else {
        throw new Error('Failed to create audio file entity')
      }
    } catch (error) {
      onError(error)
      enqueueSnackbar('Upload failed', { variant: 'error' })
    } finally {
      setUploading(false)
    }
  }

  const beforeUpload = file => {
    const isAudio = file.type.startsWith('audio/')
    if (!isAudio) {
      message.error(`${file.name} is not an audio file`)
    }
    return isAudio || Upload.LIST_IGNORE
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Upload Audio File</Title>
      <Paragraph>
        Upload your audio files here to be used for training voice cloning
        models. Ensure the audio is clear and in a supported format.
      </Paragraph>
      <Dragger
        fileList={fileList}
        customRequest={handleUpload}
        beforeUpload={beforeUpload}
        multiple={false}
        maxCount={1}
        onChange={({ fileList: newFileList }) => setFileList(newFileList)}
        onRemove={file => {
          setFileList(fileList.filter(f => f.uid !== file.uid))
        }}
        disabled={uploading}
      >
        <p className="ant-upload-drag-icon">
          <InboxOutlined />
        </p>
        <p className="ant-upload-text">
          Click or drag file to this area to upload
        </p>
        <p className="ant-upload-hint">
          Support for a single upload. Strictly prohibit from uploading company
          data or other band files
        </p>
      </Dragger>
      <Button
        type="primary"
        onClick={() => router.push('/select-model')}
        style={{ marginTop: 16 }}
        disabled={fileList.length === 0}
      >
        Next: Select Model
      </Button>
    </PageLayout>
  )
}
