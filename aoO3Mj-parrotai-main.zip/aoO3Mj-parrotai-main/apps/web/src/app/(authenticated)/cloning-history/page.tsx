'use client'

import React, { useEffect, useState } from 'react'
import { Typography, Table, Space, Button } from 'antd'
import { EyeOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function CloningHistoryPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [clonedVoices, setClonedVoices] = useState([])

  useEffect(() => {
    if (userId) {
      Api.ClonedVoice.findManyByUserId(userId, {
        includes: ['audioFile', 'voiceModel'],
      })
        .then(setClonedVoices)
        .catch(() =>
          enqueueSnackbar('Failed to fetch cloning history', {
            variant: 'error',
          }),
        )
    }
  }, [userId])

  const columns = [
    {
      title: 'Cloned Filename',
      dataIndex: 'clonedFilename',
      key: 'clonedFilename',
    },
    {
      title: 'Model Used',
      dataIndex: ['voiceModel', 'name'],
      key: 'voiceModel',
    },
    {
      title: 'Date Created',
      dataIndex: 'dateCreated',
      key: 'dateCreated',
      render: text => dayjs(text).format('DD/MM/YYYY'),
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_, record) => (
        <Space size="middle">
          <Button
            icon={<EyeOutlined />}
            onClick={() => router.push(`/cloned-voice/${record.id}`)}
          >
            View Details
          </Button>
        </Space>
      ),
    },
  ]

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Cloning History</Title>
      <Text>
        Below is a history of all the voice cloning activities you have
        performed, including details about the cloned voices and the models
        used.
      </Text>
      <Table
        columns={columns}
        dataSource={clonedVoices}
        rowKey="id"
        style={{ marginTop: '20px' }}
      />
    </PageLayout>
  )
}
