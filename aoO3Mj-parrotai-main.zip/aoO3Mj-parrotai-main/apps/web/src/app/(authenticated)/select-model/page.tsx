'use client'

import React, { useEffect, useState } from 'react'
import { Typography, Card, Row, Col, Button } from 'antd'
import { AudioOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function SelectModelPage() {
  const router = useRouter()
  const { enqueueSnackbar } = useSnackbar()
  const [voiceModels, setVoiceModels] = useState([])

  useEffect(() => {
    const fetchVoiceModels = async () => {
      try {
        const models = await Api.VoiceModel.findMany()
        setVoiceModels(models)
      } catch (error) {
        enqueueSnackbar('Failed to fetch voice models', { variant: 'error' })
      }
    }

    fetchVoiceModels()
  }, [])

  const handleSelectModel = modelId => {
    router.push(`/upload-audio?modelId=${modelId}`)
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Select a Voice Cloning Model</Title>
      <Text>Select a model to use for cloning your audio files.</Text>
      <Row gutter={[16, 16]} style={{ marginTop: '20px' }}>
        {voiceModels?.map(model => (
          <Col xs={24} sm={12} md={8} lg={6} key={model.id}>
            <Card
              hoverable
              actions={[
                <Button
                  type="primary"
                  onClick={() => handleSelectModel(model.id)}
                  icon={<AudioOutlined />}
                >
                  Select
                </Button>,
              ]}
            >
              <Card.Meta
                title={model.name}
                description={model.description || 'No description'}
              />
            </Card>
          </Col>
        ))}
      </Row>
    </PageLayout>
  )
}
