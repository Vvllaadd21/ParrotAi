import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { ClonedVoiceDomainModule } from '../domain'
import { ClonedVoiceController } from './clonedVoice.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { ClonedVoiceByUserController } from './clonedVoiceByUser.controller'

import { AudioFileDomainModule } from '../../../modules/audioFile/domain'

import { ClonedVoiceByAudioFileController } from './clonedVoiceByAudioFile.controller'

import { VoiceModelDomainModule } from '../../../modules/voiceModel/domain'

import { ClonedVoiceByVoiceModelController } from './clonedVoiceByVoiceModel.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    ClonedVoiceDomainModule,

    UserDomainModule,

    AudioFileDomainModule,

    VoiceModelDomainModule,
  ],
  controllers: [
    ClonedVoiceController,

    ClonedVoiceByUserController,

    ClonedVoiceByAudioFileController,

    ClonedVoiceByVoiceModelController,
  ],
  providers: [],
})
export class ClonedVoiceApplicationModule {}
