import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  ClonedVoice,
  ClonedVoiceDomainFacade,
} from '@server/modules/clonedVoice/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { ClonedVoiceApplicationEvent } from './clonedVoice.application.event'
import { ClonedVoiceCreateDto, ClonedVoiceUpdateDto } from './clonedVoice.dto'

@Controller('/v1/clonedVoices')
export class ClonedVoiceController {
  constructor(
    private eventService: EventService,
    private clonedVoiceDomainFacade: ClonedVoiceDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.clonedVoiceDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: ClonedVoiceCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.clonedVoiceDomainFacade.create(body)

    await this.eventService.emit<ClonedVoiceApplicationEvent.ClonedVoiceCreated.Payload>(
      ClonedVoiceApplicationEvent.ClonedVoiceCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:clonedVoiceId')
  async findOne(
    @Param('clonedVoiceId') clonedVoiceId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.clonedVoiceDomainFacade.findOneByIdOrFail(
      clonedVoiceId,
      queryOptions,
    )

    return item
  }

  @Patch('/:clonedVoiceId')
  async update(
    @Param('clonedVoiceId') clonedVoiceId: string,
    @Body() body: ClonedVoiceUpdateDto,
  ) {
    const item =
      await this.clonedVoiceDomainFacade.findOneByIdOrFail(clonedVoiceId)

    const itemUpdated = await this.clonedVoiceDomainFacade.update(
      item,
      body as Partial<ClonedVoice>,
    )
    return itemUpdated
  }

  @Delete('/:clonedVoiceId')
  async delete(@Param('clonedVoiceId') clonedVoiceId: string) {
    const item =
      await this.clonedVoiceDomainFacade.findOneByIdOrFail(clonedVoiceId)

    await this.clonedVoiceDomainFacade.delete(item)

    return item
  }
}
