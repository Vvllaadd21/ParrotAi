import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator'

export class ClonedVoiceCreateDto {
  @IsString()
  @IsNotEmpty()
  clonedFilename: string

  @IsString()
  @IsNotEmpty()
  clonedFilepathUrl: string

  @IsString()
  @IsOptional()
  userId?: string

  @IsString()
  @IsOptional()
  audioFileId?: string

  @IsString()
  @IsOptional()
  voiceModelId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}

export class ClonedVoiceUpdateDto {
  @IsString()
  @IsOptional()
  clonedFilename?: string

  @IsString()
  @IsOptional()
  clonedFilepathUrl?: string

  @IsString()
  @IsOptional()
  userId?: string

  @IsString()
  @IsOptional()
  audioFileId?: string

  @IsString()
  @IsOptional()
  voiceModelId?: string

  @IsString()
  @IsOptional()
  dateCreated?: string

  @IsString()
  @IsOptional()
  dateDeleted?: string

  @IsString()
  @IsOptional()
  dateUpdated?: string
}
