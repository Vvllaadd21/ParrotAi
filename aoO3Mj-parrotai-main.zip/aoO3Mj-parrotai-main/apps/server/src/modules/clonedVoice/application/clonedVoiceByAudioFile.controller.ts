import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { ClonedVoiceDomainFacade } from '@server/modules/clonedVoice/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { ClonedVoiceApplicationEvent } from './clonedVoice.application.event'
import { ClonedVoiceCreateDto } from './clonedVoice.dto'

import { AudioFileDomainFacade } from '../../audioFile/domain'

@Controller('/v1/audioFiles')
export class ClonedVoiceByAudioFileController {
  constructor(
    private audioFileDomainFacade: AudioFileDomainFacade,

    private clonedVoiceDomainFacade: ClonedVoiceDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/audioFile/:audioFileId/clonedVoices')
  async findManyAudioFileId(
    @Param('audioFileId') audioFileId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent =
      await this.audioFileDomainFacade.findOneByIdOrFail(audioFileId)

    const items = await this.clonedVoiceDomainFacade.findManyByAudioFile(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/audioFile/:audioFileId/clonedVoices')
  async createByAudioFileId(
    @Param('audioFileId') audioFileId: string,
    @Body() body: ClonedVoiceCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, audioFileId }

    const item = await this.clonedVoiceDomainFacade.create(valuesUpdated)

    await this.eventService.emit<ClonedVoiceApplicationEvent.ClonedVoiceCreated.Payload>(
      ClonedVoiceApplicationEvent.ClonedVoiceCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
