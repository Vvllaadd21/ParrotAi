import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { ClonedVoiceDomainFacade } from '@server/modules/clonedVoice/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { ClonedVoiceApplicationEvent } from './clonedVoice.application.event'
import { ClonedVoiceCreateDto } from './clonedVoice.dto'

import { UserDomainFacade } from '../../user/domain'

@Controller('/v1/users')
export class ClonedVoiceByUserController {
  constructor(
    private userDomainFacade: UserDomainFacade,

    private clonedVoiceDomainFacade: ClonedVoiceDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/user/:userId/clonedVoices')
  async findManyUserId(
    @Param('userId') userId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.userDomainFacade.findOneByIdOrFail(userId)

    const items = await this.clonedVoiceDomainFacade.findManyByUser(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/user/:userId/clonedVoices')
  async createByUserId(
    @Param('userId') userId: string,
    @Body() body: ClonedVoiceCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, userId }

    const item = await this.clonedVoiceDomainFacade.create(valuesUpdated)

    await this.eventService.emit<ClonedVoiceApplicationEvent.ClonedVoiceCreated.Payload>(
      ClonedVoiceApplicationEvent.ClonedVoiceCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
