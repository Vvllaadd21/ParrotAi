export namespace ClonedVoiceApplicationEvent {
  export namespace ClonedVoiceCreated {
    export const key = 'clonedVoice.application.clonedVoice.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
