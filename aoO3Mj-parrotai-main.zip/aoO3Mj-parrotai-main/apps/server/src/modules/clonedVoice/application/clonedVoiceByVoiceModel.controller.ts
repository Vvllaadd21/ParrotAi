import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { ClonedVoiceDomainFacade } from '@server/modules/clonedVoice/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { ClonedVoiceApplicationEvent } from './clonedVoice.application.event'
import { ClonedVoiceCreateDto } from './clonedVoice.dto'

import { VoiceModelDomainFacade } from '../../voiceModel/domain'

@Controller('/v1/voiceModels')
export class ClonedVoiceByVoiceModelController {
  constructor(
    private voiceModelDomainFacade: VoiceModelDomainFacade,

    private clonedVoiceDomainFacade: ClonedVoiceDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/voiceModel/:voiceModelId/clonedVoices')
  async findManyVoiceModelId(
    @Param('voiceModelId') voiceModelId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent =
      await this.voiceModelDomainFacade.findOneByIdOrFail(voiceModelId)

    const items = await this.clonedVoiceDomainFacade.findManyByVoiceModel(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/voiceModel/:voiceModelId/clonedVoices')
  async createByVoiceModelId(
    @Param('voiceModelId') voiceModelId: string,
    @Body() body: ClonedVoiceCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, voiceModelId }

    const item = await this.clonedVoiceDomainFacade.create(valuesUpdated)

    await this.eventService.emit<ClonedVoiceApplicationEvent.ClonedVoiceCreated.Payload>(
      ClonedVoiceApplicationEvent.ClonedVoiceCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
