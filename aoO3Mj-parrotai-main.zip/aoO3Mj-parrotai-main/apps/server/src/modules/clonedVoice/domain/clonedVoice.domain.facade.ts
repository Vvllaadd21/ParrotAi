import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { DatabaseHelper } from '../../../core/database'
import { RequestHelper } from '../../../helpers/request'
import { ClonedVoice } from './clonedVoice.model'

import { User } from '../../user/domain'

import { AudioFile } from '../../audioFile/domain'

import { VoiceModel } from '../../voiceModel/domain'

@Injectable()
export class ClonedVoiceDomainFacade {
  constructor(
    @InjectRepository(ClonedVoice)
    private repository: Repository<ClonedVoice>,
    private databaseHelper: DatabaseHelper,
  ) {}

  async create(values: Partial<ClonedVoice>): Promise<ClonedVoice> {
    return this.repository.save(values)
  }

  async update(
    item: ClonedVoice,
    values: Partial<ClonedVoice>,
  ): Promise<ClonedVoice> {
    const itemUpdated = { ...item, ...values }

    return this.repository.save(itemUpdated)
  }

  async delete(item: ClonedVoice): Promise<void> {
    await this.repository.softDelete(item.id)
  }

  async findMany(
    queryOptions: RequestHelper.QueryOptions<ClonedVoice> = {},
  ): Promise<ClonedVoice[]> {
    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptions,
    )

    return query.getMany()
  }

  async findOneByIdOrFail(
    id: string,
    queryOptions: RequestHelper.QueryOptions<ClonedVoice> = {},
  ): Promise<ClonedVoice> {
    if (!id) {
      this.databaseHelper.invalidQueryWhere('id')
    }

    const queryOptionsEnsured = {
      includes: queryOptions?.includes,
      filters: {
        id: id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    const item = await query.getOne()

    if (!item) {
      this.databaseHelper.notFoundByQuery(queryOptionsEnsured.filters)
    }

    return item
  }

  async findManyByUser(
    item: User,
    queryOptions: RequestHelper.QueryOptions<ClonedVoice> = {},
  ): Promise<ClonedVoice[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('user')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        userId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }

  async findManyByAudioFile(
    item: AudioFile,
    queryOptions: RequestHelper.QueryOptions<ClonedVoice> = {},
  ): Promise<ClonedVoice[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('audioFile')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        audioFileId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }

  async findManyByVoiceModel(
    item: VoiceModel,
    queryOptions: RequestHelper.QueryOptions<ClonedVoice> = {},
  ): Promise<ClonedVoice[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('voiceModel')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        voiceModelId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }
}
