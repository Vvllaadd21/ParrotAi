import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { ClonedVoiceDomainFacade } from './clonedVoice.domain.facade'
import { ClonedVoice } from './clonedVoice.model'

@Module({
  imports: [TypeOrmModule.forFeature([ClonedVoice]), DatabaseHelperModule],
  providers: [ClonedVoiceDomainFacade, ClonedVoiceDomainFacade],
  exports: [ClonedVoiceDomainFacade],
})
export class ClonedVoiceDomainModule {}
