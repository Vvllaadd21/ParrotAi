import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { User } from '../../../modules/user/domain'

import { AudioFile } from '../../../modules/audioFile/domain'

import { VoiceModel } from '../../../modules/voiceModel/domain'

@Entity()
export class ClonedVoice {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({})
  clonedFilename: string

  @Column({})
  clonedFilepathUrl: string

  @Column({})
  userId: string

  @ManyToOne(() => User, parent => parent.clonedVoices)
  @JoinColumn({ name: 'userId' })
  user?: User

  @Column({})
  audioFileId: string

  @ManyToOne(() => AudioFile, parent => parent.clonedVoices)
  @JoinColumn({ name: 'audioFileId' })
  audioFile?: AudioFile

  @Column({})
  voiceModelId: string

  @ManyToOne(() => VoiceModel, parent => parent.clonedVoices)
  @JoinColumn({ name: 'voiceModelId' })
  voiceModel?: VoiceModel

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
