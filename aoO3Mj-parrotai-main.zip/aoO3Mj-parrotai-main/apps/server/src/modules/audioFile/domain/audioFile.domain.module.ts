import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { AudioFileDomainFacade } from './audioFile.domain.facade'
import { AudioFile } from './audioFile.model'

@Module({
  imports: [TypeOrmModule.forFeature([AudioFile]), DatabaseHelperModule],
  providers: [AudioFileDomainFacade, AudioFileDomainFacade],
  exports: [AudioFileDomainFacade],
})
export class AudioFileDomainModule {}
