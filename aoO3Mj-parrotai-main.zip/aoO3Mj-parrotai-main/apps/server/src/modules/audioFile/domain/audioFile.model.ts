import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { User } from '../../../modules/user/domain'

import { VoiceModel } from '../../../modules/voiceModel/domain'

import { ClonedVoice } from '../../../modules/clonedVoice/domain'

@Entity()
export class AudioFile {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({})
  filename: string

  @Column({})
  filepathUrl: string

  @Column({})
  userId: string

  @ManyToOne(() => User, parent => parent.audioFiles)
  @JoinColumn({ name: 'userId' })
  user?: User

  @Column({})
  modelId: string

  @ManyToOne(() => VoiceModel, parent => parent.audioFilesAsModel)
  @JoinColumn({ name: 'modelId' })
  model?: VoiceModel

  @OneToMany(() => ClonedVoice, child => child.audioFile)
  clonedVoices?: ClonedVoice[]

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
