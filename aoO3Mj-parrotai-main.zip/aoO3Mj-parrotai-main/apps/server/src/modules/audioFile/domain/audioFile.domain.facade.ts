import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { DatabaseHelper } from '../../../core/database'
import { RequestHelper } from '../../../helpers/request'
import { AudioFile } from './audioFile.model'

import { User } from '../../user/domain'

import { VoiceModel } from '../../voiceModel/domain'

@Injectable()
export class AudioFileDomainFacade {
  constructor(
    @InjectRepository(AudioFile)
    private repository: Repository<AudioFile>,
    private databaseHelper: DatabaseHelper,
  ) {}

  async create(values: Partial<AudioFile>): Promise<AudioFile> {
    return this.repository.save(values)
  }

  async update(
    item: AudioFile,
    values: Partial<AudioFile>,
  ): Promise<AudioFile> {
    const itemUpdated = { ...item, ...values }

    return this.repository.save(itemUpdated)
  }

  async delete(item: AudioFile): Promise<void> {
    await this.repository.softDelete(item.id)
  }

  async findMany(
    queryOptions: RequestHelper.QueryOptions<AudioFile> = {},
  ): Promise<AudioFile[]> {
    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptions,
    )

    return query.getMany()
  }

  async findOneByIdOrFail(
    id: string,
    queryOptions: RequestHelper.QueryOptions<AudioFile> = {},
  ): Promise<AudioFile> {
    if (!id) {
      this.databaseHelper.invalidQueryWhere('id')
    }

    const queryOptionsEnsured = {
      includes: queryOptions?.includes,
      filters: {
        id: id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    const item = await query.getOne()

    if (!item) {
      this.databaseHelper.notFoundByQuery(queryOptionsEnsured.filters)
    }

    return item
  }

  async findManyByUser(
    item: User,
    queryOptions: RequestHelper.QueryOptions<AudioFile> = {},
  ): Promise<AudioFile[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('user')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        userId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }

  async findManyByModel(
    item: VoiceModel,
    queryOptions: RequestHelper.QueryOptions<AudioFile> = {},
  ): Promise<AudioFile[]> {
    if (!item) {
      this.databaseHelper.invalidQueryWhere('model')
    }

    const queryOptionsEnsured = {
      includes: queryOptions.includes,
      orders: queryOptions.orders,
      filters: {
        ...queryOptions.filters,
        modelId: item.id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    return query.getMany()
  }
}
