import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  AudioFile,
  AudioFileDomainFacade,
} from '@server/modules/audioFile/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { AudioFileApplicationEvent } from './audioFile.application.event'
import { AudioFileCreateDto, AudioFileUpdateDto } from './audioFile.dto'

@Controller('/v1/audioFiles')
export class AudioFileController {
  constructor(
    private eventService: EventService,
    private audioFileDomainFacade: AudioFileDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.audioFileDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: AudioFileCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.audioFileDomainFacade.create(body)

    await this.eventService.emit<AudioFileApplicationEvent.AudioFileCreated.Payload>(
      AudioFileApplicationEvent.AudioFileCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:audioFileId')
  async findOne(
    @Param('audioFileId') audioFileId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.audioFileDomainFacade.findOneByIdOrFail(
      audioFileId,
      queryOptions,
    )

    return item
  }

  @Patch('/:audioFileId')
  async update(
    @Param('audioFileId') audioFileId: string,
    @Body() body: AudioFileUpdateDto,
  ) {
    const item = await this.audioFileDomainFacade.findOneByIdOrFail(audioFileId)

    const itemUpdated = await this.audioFileDomainFacade.update(
      item,
      body as Partial<AudioFile>,
    )
    return itemUpdated
  }

  @Delete('/:audioFileId')
  async delete(@Param('audioFileId') audioFileId: string) {
    const item = await this.audioFileDomainFacade.findOneByIdOrFail(audioFileId)

    await this.audioFileDomainFacade.delete(item)

    return item
  }
}
