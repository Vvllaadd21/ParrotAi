import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { AudioFileDomainModule } from '../domain'
import { AudioFileController } from './audioFile.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { AudioFileByUserController } from './audioFileByUser.controller'

import { VoiceModelDomainModule } from '../../../modules/voiceModel/domain'

import { AudioFileByVoiceModelController } from './audioFileByVoiceModel.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    AudioFileDomainModule,

    UserDomainModule,

    VoiceModelDomainModule,
  ],
  controllers: [
    AudioFileController,

    AudioFileByUserController,

    AudioFileByVoiceModelController,
  ],
  providers: [],
})
export class AudioFileApplicationModule {}
