export namespace AudioFileApplicationEvent {
  export namespace AudioFileCreated {
    export const key = 'audioFile.application.audioFile.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
