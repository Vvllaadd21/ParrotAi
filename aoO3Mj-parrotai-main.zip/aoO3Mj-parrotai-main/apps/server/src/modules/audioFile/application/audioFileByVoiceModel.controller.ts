import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { AudioFileDomainFacade } from '@server/modules/audioFile/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { AudioFileApplicationEvent } from './audioFile.application.event'
import { AudioFileCreateDto } from './audioFile.dto'

import { VoiceModelDomainFacade } from '../../voiceModel/domain'

@Controller('/v1/voiceModels')
export class AudioFileByVoiceModelController {
  constructor(
    private voiceModelDomainFacade: VoiceModelDomainFacade,

    private audioFileDomainFacade: AudioFileDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/model/:modelId/audioFiles')
  async findManyModelId(
    @Param('modelId') modelId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.voiceModelDomainFacade.findOneByIdOrFail(modelId)

    const items = await this.audioFileDomainFacade.findManyByModel(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/model/:modelId/audioFiles')
  async createByModelId(
    @Param('modelId') modelId: string,
    @Body() body: AudioFileCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, modelId }

    const item = await this.audioFileDomainFacade.create(valuesUpdated)

    await this.eventService.emit<AudioFileApplicationEvent.AudioFileCreated.Payload>(
      AudioFileApplicationEvent.AudioFileCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
