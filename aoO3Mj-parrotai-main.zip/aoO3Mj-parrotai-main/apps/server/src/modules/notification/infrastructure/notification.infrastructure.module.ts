import { Module } from '@nestjs/common'
import { SocketModule } from '@server/libraries/socket'
import { AuthorizationDomainModule } from '@server/modules/authorization/domain'
import { NotificationDomainModule } from '../domain'

import { NotificationVoiceModelSubscriber } from './subscribers/notification.voiceModel.subscriber'

import { NotificationAudioFileSubscriber } from './subscribers/notification.audioFile.subscriber'

import { NotificationClonedVoiceSubscriber } from './subscribers/notification.clonedVoice.subscriber'

@Module({
  imports: [AuthorizationDomainModule, NotificationDomainModule, SocketModule],
  providers: [
    NotificationVoiceModelSubscriber,

    NotificationAudioFileSubscriber,

    NotificationClonedVoiceSubscriber,
  ],
  exports: [],
})
export class NotificationInfrastructureModule {}
