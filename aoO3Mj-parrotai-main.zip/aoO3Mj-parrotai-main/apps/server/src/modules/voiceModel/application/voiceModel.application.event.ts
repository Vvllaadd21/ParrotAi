export namespace VoiceModelApplicationEvent {
  export namespace VoiceModelCreated {
    export const key = 'voiceModel.application.voiceModel.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
