import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { VoiceModelDomainModule } from '../domain'
import { VoiceModelController } from './voiceModel.controller'

@Module({
  imports: [AuthenticationDomainModule, VoiceModelDomainModule],
  controllers: [VoiceModelController],
  providers: [],
})
export class VoiceModelApplicationModule {}
