import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import {
  VoiceModel,
  VoiceModelDomainFacade,
} from '@server/modules/voiceModel/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { VoiceModelApplicationEvent } from './voiceModel.application.event'
import { VoiceModelCreateDto, VoiceModelUpdateDto } from './voiceModel.dto'

@Controller('/v1/voiceModels')
export class VoiceModelController {
  constructor(
    private eventService: EventService,
    private voiceModelDomainFacade: VoiceModelDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.voiceModelDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: VoiceModelCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.voiceModelDomainFacade.create(body)

    await this.eventService.emit<VoiceModelApplicationEvent.VoiceModelCreated.Payload>(
      VoiceModelApplicationEvent.VoiceModelCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:voiceModelId')
  async findOne(
    @Param('voiceModelId') voiceModelId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.voiceModelDomainFacade.findOneByIdOrFail(
      voiceModelId,
      queryOptions,
    )

    return item
  }

  @Patch('/:voiceModelId')
  async update(
    @Param('voiceModelId') voiceModelId: string,
    @Body() body: VoiceModelUpdateDto,
  ) {
    const item =
      await this.voiceModelDomainFacade.findOneByIdOrFail(voiceModelId)

    const itemUpdated = await this.voiceModelDomainFacade.update(
      item,
      body as Partial<VoiceModel>,
    )
    return itemUpdated
  }

  @Delete('/:voiceModelId')
  async delete(@Param('voiceModelId') voiceModelId: string) {
    const item =
      await this.voiceModelDomainFacade.findOneByIdOrFail(voiceModelId)

    await this.voiceModelDomainFacade.delete(item)

    return item
  }
}
