import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { DatabaseHelper } from '../../../core/database'
import { RequestHelper } from '../../../helpers/request'
import { VoiceModel } from './voiceModel.model'

@Injectable()
export class VoiceModelDomainFacade {
  constructor(
    @InjectRepository(VoiceModel)
    private repository: Repository<VoiceModel>,
    private databaseHelper: DatabaseHelper,
  ) {}

  async create(values: Partial<VoiceModel>): Promise<VoiceModel> {
    return this.repository.save(values)
  }

  async update(
    item: VoiceModel,
    values: Partial<VoiceModel>,
  ): Promise<VoiceModel> {
    const itemUpdated = { ...item, ...values }

    return this.repository.save(itemUpdated)
  }

  async delete(item: VoiceModel): Promise<void> {
    await this.repository.softDelete(item.id)
  }

  async findMany(
    queryOptions: RequestHelper.QueryOptions<VoiceModel> = {},
  ): Promise<VoiceModel[]> {
    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptions,
    )

    return query.getMany()
  }

  async findOneByIdOrFail(
    id: string,
    queryOptions: RequestHelper.QueryOptions<VoiceModel> = {},
  ): Promise<VoiceModel> {
    if (!id) {
      this.databaseHelper.invalidQueryWhere('id')
    }

    const queryOptionsEnsured = {
      includes: queryOptions?.includes,
      filters: {
        id: id,
      },
    }

    const query = this.databaseHelper.applyQueryOptions(
      this.repository,
      queryOptionsEnsured,
    )

    const item = await query.getOne()

    if (!item) {
      this.databaseHelper.notFoundByQuery(queryOptionsEnsured.filters)
    }

    return item
  }
}
