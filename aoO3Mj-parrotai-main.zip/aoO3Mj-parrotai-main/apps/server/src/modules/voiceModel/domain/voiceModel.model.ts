import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { AudioFile } from '../../../modules/audioFile/domain'

import { ClonedVoice } from '../../../modules/clonedVoice/domain'

@Entity()
export class VoiceModel {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({})
  name: string

  @Column({ nullable: true })
  description?: string

  @OneToMany(() => AudioFile, child => child.model)
  audioFilesAsModel?: AudioFile[]

  @OneToMany(() => ClonedVoice, child => child.voiceModel)
  clonedVoices?: ClonedVoice[]

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
