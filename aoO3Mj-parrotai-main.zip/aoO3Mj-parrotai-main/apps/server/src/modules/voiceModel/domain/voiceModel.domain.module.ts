import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { VoiceModelDomainFacade } from './voiceModel.domain.facade'
import { VoiceModel } from './voiceModel.model'

@Module({
  imports: [TypeOrmModule.forFeature([VoiceModel]), DatabaseHelperModule],
  providers: [VoiceModelDomainFacade, VoiceModelDomainFacade],
  exports: [VoiceModelDomainFacade],
})
export class VoiceModelDomainModule {}
