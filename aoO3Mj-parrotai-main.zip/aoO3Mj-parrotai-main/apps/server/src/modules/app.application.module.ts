import { Module } from '@nestjs/common'
import { AuthenticationApplicationModule } from './authentication/application'
import { AuthorizationApplicationModule } from './authorization/application'
import { UserApplicationModule } from './user/application'

import { VoiceModelApplicationModule } from './voiceModel/application'

import { AudioFileApplicationModule } from './audioFile/application'

import { ClonedVoiceApplicationModule } from './clonedVoice/application'

import { AiApplicationModule } from './ai/application/ai.application.module'
import { NotificationApplicationModule } from './notification/application/notification.application.module'
import { UploadApplicationModule } from './upload/application/upload.application.module'

@Module({
  imports: [
    AuthenticationApplicationModule,
    UserApplicationModule,
    AuthorizationApplicationModule,
    NotificationApplicationModule,
    AiApplicationModule,
    UploadApplicationModule,

    VoiceModelApplicationModule,

    AudioFileApplicationModule,

    ClonedVoiceApplicationModule,
  ],
  controllers: [],
  providers: [],
})
export class AppApplicationModule {}
