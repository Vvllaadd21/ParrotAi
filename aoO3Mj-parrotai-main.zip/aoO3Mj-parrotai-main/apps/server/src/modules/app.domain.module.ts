import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from './authentication/domain'
import { AuthorizationDomainModule } from './authorization/domain'

import { UserDomainModule } from './user/domain'

import { NotificationDomainModule } from './notification/domain'

import { VoiceModelDomainModule } from './voiceModel/domain'

import { AudioFileDomainModule } from './audioFile/domain'

import { ClonedVoiceDomainModule } from './clonedVoice/domain'

@Module({
  imports: [
    AuthenticationDomainModule,
    AuthorizationDomainModule,
    UserDomainModule,
    NotificationDomainModule,

    VoiceModelDomainModule,

    AudioFileDomainModule,

    ClonedVoiceDomainModule,
  ],
  controllers: [],
  providers: [],
})
export class AppDomainModule {}
